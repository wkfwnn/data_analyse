﻿namespace C_Sharp_Demo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.grp_Network = new System.Windows.Forms.GroupBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.radbtn_ServerMode = new System.Windows.Forms.RadioButton();
            this.radbtn_FixIPMode = new System.Windows.Forms.RadioButton();
            this.edt_NetworkID = new System.Windows.Forms.TextBox();
            this.lbl_NetworkID = new System.Windows.Forms.Label();
            this.edt_StaticIP_IP = new System.Windows.Forms.TextBox();
            this.spnedt_StaticIP_Port = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cbb_Pixel = new System.Windows.Forms.ComboBox();
            this.cbb_Color = new System.Windows.Forms.ComboBox();
            this.spnedt_Height = new System.Windows.Forms.NumericUpDown();
            this.spnedt_Width = new System.Windows.Forms.NumericUpDown();
            this.cbb_SendMode = new System.Windows.Forms.ComboBox();
            this.cbb_ControllerType = new System.Windows.Forms.ComboBox();
            this.spnedt_PNo = new System.Windows.Forms.NumericUpDown();
            this.grp_SerialPort = new System.Windows.Forms.GroupBox();
            this.cbb_Baud = new System.Windows.Forms.ComboBox();
            this.cbb_Comm = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grp_Server = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.edtTransitNetworkID = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.edtTransitBarcode = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.edt_Password = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.edt_User = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.edt_ServerIP = new System.Windows.Forms.TextBox();
            this.edt_ServerPort = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.grp_Savefile = new System.Windows.Forms.GroupBox();
            this.edt_SaveFile = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.mmo_FunResultInfo = new System.Windows.Forms.RichTextBox();
            this.grp_AddDYAreaFile = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.chk_SingleLine = new System.Windows.Forms.CheckBox();
            this.btn_UpDateDYArea = new System.Windows.Forms.Button();
            this.tlbtn_DelFile = new System.Windows.Forms.Button();
            this.spnedt_DYAreaShowTime = new System.Windows.Forms.NumericUpDown();
            this.spnedt_DYAreaRunSpeed = new System.Windows.Forms.NumericUpDown();
            this.cbb_DYAreaStunt = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.btn_DeleteAllDYArea = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.btn_DeleteScreenDynamicAreas = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.grp_AddDynamicArea = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.edt_RelatePro = new System.Windows.Forms.TextBox();
            this.radbtn_SelRelatePro = new System.Windows.Forms.RadioButton();
            this.radbtn_AllRelatePro = new System.Windows.Forms.RadioButton();
            this.radbtn_NoRelate = new System.Windows.Forms.RadioButton();
            this.cbb_PlayPriority = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.grp_DYAreaF = new System.Windows.Forms.GroupBox();
            this.spnedt_DYAreaFMoveStep = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.spnedt_DYAreaFRunSpeed = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.cbb_DYAreaFStunt = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.spnedt_DYAreaFMuli = new System.Windows.Forms.NumericUpDown();
            this.spnedt_DYAreaFSingleColor = new System.Windows.Forms.NumericUpDown();
            this.spnedt_DYAreaFSingle = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.radbtn_DYAreaFMuli = new System.Windows.Forms.RadioButton();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.radbtn_DYAreaFSingle = new System.Windows.Forms.RadioButton();
            this.chk_DYAreaF = new System.Windows.Forms.CheckBox();
            this.cbb_RunMode = new System.Windows.Forms.ComboBox();
            this.spnedt_TimeOut = new System.Windows.Forms.NumericUpDown();
            this.spnedt_DYAreaH = new System.Windows.Forms.NumericUpDown();
            this.spnedt_DYAreaW = new System.Windows.Forms.NumericUpDown();
            this.spnedt_DYAreaY = new System.Windows.Forms.NumericUpDown();
            this.spnedt_DYAreaX = new System.Windows.Forms.NumericUpDown();
            this.spnedt_DYAreaID = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button10 = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.cbb_StaticIpMode = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.grp_Network.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_StaticIP_Port)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_Height)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_Width)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_PNo)).BeginInit();
            this.grp_SerialPort.SuspendLayout();
            this.grp_Server.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edt_ServerPort)).BeginInit();
            this.grp_Savefile.SuspendLayout();
            this.grp_AddDYAreaFile.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaShowTime)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaRunSpeed)).BeginInit();
            this.grp_AddDynamicArea.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grp_DYAreaF.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFMoveStep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFRunSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFMuli)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFSingleColor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFSingle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_TimeOut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaID)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbb_StaticIpMode);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.grp_Network);
            this.groupBox1.Controls.Add(this.cbb_Pixel);
            this.groupBox1.Controls.Add(this.cbb_Color);
            this.groupBox1.Controls.Add(this.spnedt_Height);
            this.groupBox1.Controls.Add(this.spnedt_Width);
            this.groupBox1.Controls.Add(this.cbb_SendMode);
            this.groupBox1.Controls.Add(this.cbb_ControllerType);
            this.groupBox1.Controls.Add(this.spnedt_PNo);
            this.groupBox1.Controls.Add(this.grp_SerialPort);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.grp_Server);
            this.groupBox1.Controls.Add(this.grp_Savefile);
            this.groupBox1.Location = new System.Drawing.Point(2, 49);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(700, 155);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "第二步-----显示屏初始化";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(3, 127);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(694, 25);
            this.panel2.TabIndex = 25;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Right;
            this.button1.Location = new System.Drawing.Point(463, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 25);
            this.button1.TabIndex = 35;
            this.button1.Text = "添加显示屏";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Right;
            this.button2.Location = new System.Drawing.Point(586, 0);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(108, 25);
            this.button2.TabIndex = 34;
            this.button2.Text = "删除显示屏";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // grp_Network
            // 
            this.grp_Network.Controls.Add(this.button11);
            this.grp_Network.Controls.Add(this.button5);
            this.grp_Network.Controls.Add(this.radbtn_ServerMode);
            this.grp_Network.Controls.Add(this.radbtn_FixIPMode);
            this.grp_Network.Controls.Add(this.edt_NetworkID);
            this.grp_Network.Controls.Add(this.lbl_NetworkID);
            this.grp_Network.Controls.Add(this.edt_StaticIP_IP);
            this.grp_Network.Controls.Add(this.spnedt_StaticIP_Port);
            this.grp_Network.Controls.Add(this.label9);
            this.grp_Network.Controls.Add(this.label8);
            this.grp_Network.Location = new System.Drawing.Point(10, 56);
            this.grp_Network.Name = "grp_Network";
            this.grp_Network.Size = new System.Drawing.Size(697, 64);
            this.grp_Network.TabIndex = 21;
            this.grp_Network.TabStop = false;
            this.grp_Network.Text = "网络配置";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(588, 33);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(86, 23);
            this.button11.TabIndex = 25;
            this.button11.Text = "关闭服务器";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Visible = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(492, 32);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(87, 23);
            this.button5.TabIndex = 24;
            this.button5.Text = "启动服务器";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Visible = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // radbtn_ServerMode
            // 
            this.radbtn_ServerMode.AutoSize = true;
            this.radbtn_ServerMode.Location = new System.Drawing.Point(201, 11);
            this.radbtn_ServerMode.Name = "radbtn_ServerMode";
            this.radbtn_ServerMode.Size = new System.Drawing.Size(83, 16);
            this.radbtn_ServerMode.TabIndex = 23;
            this.radbtn_ServerMode.TabStop = true;
            this.radbtn_ServerMode.Text = "服务器模式";
            this.radbtn_ServerMode.UseVisualStyleBackColor = true;
            this.radbtn_ServerMode.CheckedChanged += new System.EventHandler(this.radbtn_FixIPMode_CheckedChanged);
            // 
            // radbtn_FixIPMode
            // 
            this.radbtn_FixIPMode.AutoSize = true;
            this.radbtn_FixIPMode.Checked = true;
            this.radbtn_FixIPMode.Location = new System.Drawing.Point(63, 13);
            this.radbtn_FixIPMode.Name = "radbtn_FixIPMode";
            this.radbtn_FixIPMode.Size = new System.Drawing.Size(83, 16);
            this.radbtn_FixIPMode.TabIndex = 22;
            this.radbtn_FixIPMode.TabStop = true;
            this.radbtn_FixIPMode.Text = "固定IP模式";
            this.radbtn_FixIPMode.UseVisualStyleBackColor = true;
            this.radbtn_FixIPMode.CheckedChanged += new System.EventHandler(this.radbtn_FixIPMode_CheckedChanged);
            // 
            // edt_NetworkID
            // 
            this.edt_NetworkID.Location = new System.Drawing.Point(378, 33);
            this.edt_NetworkID.Name = "edt_NetworkID";
            this.edt_NetworkID.Size = new System.Drawing.Size(100, 21);
            this.edt_NetworkID.TabIndex = 21;
            this.edt_NetworkID.Visible = false;
            // 
            // lbl_NetworkID
            // 
            this.lbl_NetworkID.AutoSize = true;
            this.lbl_NetworkID.Location = new System.Drawing.Point(332, 38);
            this.lbl_NetworkID.Name = "lbl_NetworkID";
            this.lbl_NetworkID.Size = new System.Drawing.Size(41, 12);
            this.lbl_NetworkID.TabIndex = 20;
            this.lbl_NetworkID.Text = "网络ID";
            this.lbl_NetworkID.Visible = false;
            // 
            // edt_StaticIP_IP
            // 
            this.edt_StaticIP_IP.Location = new System.Drawing.Point(58, 33);
            this.edt_StaticIP_IP.Name = "edt_StaticIP_IP";
            this.edt_StaticIP_IP.Size = new System.Drawing.Size(100, 21);
            this.edt_StaticIP_IP.TabIndex = 3;
            // 
            // spnedt_StaticIP_Port
            // 
            this.spnedt_StaticIP_Port.Location = new System.Drawing.Point(217, 33);
            this.spnedt_StaticIP_Port.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.spnedt_StaticIP_Port.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.spnedt_StaticIP_Port.Name = "spnedt_StaticIP_Port";
            this.spnedt_StaticIP_Port.Size = new System.Drawing.Size(95, 21);
            this.spnedt_StaticIP_Port.TabIndex = 2;
            this.spnedt_StaticIP_Port.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(183, 37);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 1;
            this.label9.Text = "端口";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "IP地址";
            // 
            // cbb_Pixel
            // 
            this.cbb_Pixel.FormattingEnabled = true;
            this.cbb_Pixel.Items.AddRange(new object[] {
            "I  (R+G)",
            "II (G+R)"});
            this.cbb_Pixel.Location = new System.Drawing.Point(508, 36);
            this.cbb_Pixel.Name = "cbb_Pixel";
            this.cbb_Pixel.Size = new System.Drawing.Size(82, 20);
            this.cbb_Pixel.TabIndex = 13;
            // 
            // cbb_Color
            // 
            this.cbb_Color.ForeColor = System.Drawing.Color.YellowGreen;
            this.cbb_Color.FormattingEnabled = true;
            this.cbb_Color.Items.AddRange(new object[] {
            "单基色",
            "双基色",
            "全彩色"});
            this.cbb_Color.Location = new System.Drawing.Point(409, 36);
            this.cbb_Color.Name = "cbb_Color";
            this.cbb_Color.Size = new System.Drawing.Size(83, 20);
            this.cbb_Color.TabIndex = 12;
            // 
            // spnedt_Height
            // 
            this.spnedt_Height.Increment = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.spnedt_Height.Location = new System.Drawing.Point(339, 36);
            this.spnedt_Height.Maximum = new decimal(new int[] {
            512,
            0,
            0,
            0});
            this.spnedt_Height.Minimum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.spnedt_Height.Name = "spnedt_Height";
            this.spnedt_Height.Size = new System.Drawing.Size(54, 21);
            this.spnedt_Height.TabIndex = 11;
            this.spnedt_Height.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            // 
            // spnedt_Width
            // 
            this.spnedt_Width.Increment = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.spnedt_Width.Location = new System.Drawing.Point(269, 36);
            this.spnedt_Width.Maximum = new decimal(new int[] {
            4096,
            0,
            0,
            0});
            this.spnedt_Width.Minimum = new decimal(new int[] {
            80,
            0,
            0,
            0});
            this.spnedt_Width.Name = "spnedt_Width";
            this.spnedt_Width.Size = new System.Drawing.Size(54, 21);
            this.spnedt_Width.TabIndex = 10;
            this.spnedt_Width.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            // 
            // cbb_SendMode
            // 
            this.cbb_SendMode.FormattingEnabled = true;
            this.cbb_SendMode.Items.AddRange(new object[] {
            "串口通讯",
            "网络通讯",
            "ONBON服务器-GPRS",
            "ONBON服务器-3G",
            "保存到文件"});
            this.cbb_SendMode.Location = new System.Drawing.Point(165, 36);
            this.cbb_SendMode.Name = "cbb_SendMode";
            this.cbb_SendMode.Size = new System.Drawing.Size(88, 20);
            this.cbb_SendMode.TabIndex = 9;
            this.cbb_SendMode.SelectedIndexChanged += new System.EventHandler(this.cbb_SendMode_SelectedIndexChanged);
            // 
            // cbb_ControllerType
            // 
            this.cbb_ControllerType.FormattingEnabled = true;
            this.cbb_ControllerType.Items.AddRange(new object[] {
            "BX-5E1",
            "BX-5E2",
            "BX-5E3",
            "BX-5Q0+",
            "BX-5Q1+",
            "BX-5Q2+"});
            this.cbb_ControllerType.Location = new System.Drawing.Point(76, 36);
            this.cbb_ControllerType.Name = "cbb_ControllerType";
            this.cbb_ControllerType.Size = new System.Drawing.Size(73, 20);
            this.cbb_ControllerType.TabIndex = 8;
            // 
            // spnedt_PNo
            // 
            this.spnedt_PNo.Location = new System.Drawing.Point(6, 36);
            this.spnedt_PNo.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.spnedt_PNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnedt_PNo.Name = "spnedt_PNo";
            this.spnedt_PNo.Size = new System.Drawing.Size(54, 21);
            this.spnedt_PNo.TabIndex = 7;
            this.spnedt_PNo.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnedt_PNo.ValueChanged += new System.EventHandler(this.spnedt_PNo_ValueChanged);
            // 
            // grp_SerialPort
            // 
            this.grp_SerialPort.Controls.Add(this.cbb_Baud);
            this.grp_SerialPort.Controls.Add(this.cbb_Comm);
            this.grp_SerialPort.Controls.Add(this.label11);
            this.grp_SerialPort.Controls.Add(this.label10);
            this.grp_SerialPort.Location = new System.Drawing.Point(7, 57);
            this.grp_SerialPort.Name = "grp_SerialPort";
            this.grp_SerialPort.Size = new System.Drawing.Size(697, 63);
            this.grp_SerialPort.TabIndex = 16;
            this.grp_SerialPort.TabStop = false;
            this.grp_SerialPort.Text = "串口配置";
            // 
            // cbb_Baud
            // 
            this.cbb_Baud.FormattingEnabled = true;
            this.cbb_Baud.Items.AddRange(new object[] {
            "9600",
            "57600"});
            this.cbb_Baud.Location = new System.Drawing.Point(232, 20);
            this.cbb_Baud.Name = "cbb_Baud";
            this.cbb_Baud.Size = new System.Drawing.Size(83, 20);
            this.cbb_Baud.TabIndex = 3;
            // 
            // cbb_Comm
            // 
            this.cbb_Comm.FormattingEnabled = true;
            this.cbb_Comm.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "COM10"});
            this.cbb_Comm.Location = new System.Drawing.Point(60, 20);
            this.cbb_Comm.Name = "cbb_Comm";
            this.cbb_Comm.Size = new System.Drawing.Size(98, 20);
            this.cbb_Comm.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(185, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "波特率";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(14, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 0;
            this.label10.Text = "串口";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(510, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "点阵类型";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(419, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "屏型";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(347, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "高度";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(270, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "宽度";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(168, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "通讯方式";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "控制器型号";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "屏号";
            // 
            // grp_Server
            // 
            this.grp_Server.Controls.Add(this.button3);
            this.grp_Server.Controls.Add(this.edtTransitNetworkID);
            this.grp_Server.Controls.Add(this.label37);
            this.grp_Server.Controls.Add(this.edtTransitBarcode);
            this.grp_Server.Controls.Add(this.label36);
            this.grp_Server.Controls.Add(this.edt_Password);
            this.grp_Server.Controls.Add(this.label30);
            this.grp_Server.Controls.Add(this.edt_User);
            this.grp_Server.Controls.Add(this.label31);
            this.grp_Server.Controls.Add(this.edt_ServerIP);
            this.grp_Server.Controls.Add(this.edt_ServerPort);
            this.grp_Server.Controls.Add(this.label32);
            this.grp_Server.Controls.Add(this.label33);
            this.grp_Server.Location = new System.Drawing.Point(3, 62);
            this.grp_Server.Name = "grp_Server";
            this.grp_Server.Size = new System.Drawing.Size(697, 59);
            this.grp_Server.TabIndex = 20;
            this.grp_Server.TabStop = false;
            this.grp_Server.Text = "ONBON服务器";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(590, 37);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(101, 23);
            this.button3.TabIndex = 28;
            this.button3.Text = "绑定无线设备";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_2);
            // 
            // edtTransitNetworkID
            // 
            this.edtTransitNetworkID.Location = new System.Drawing.Point(508, 38);
            this.edtTransitNetworkID.Name = "edtTransitNetworkID";
            this.edtTransitNetworkID.Size = new System.Drawing.Size(76, 21);
            this.edtTransitNetworkID.TabIndex = 27;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(506, 17);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(41, 12);
            this.label37.TabIndex = 26;
            this.label37.Text = "网络ID";
            // 
            // edtTransitBarcode
            // 
            this.edtTransitBarcode.Location = new System.Drawing.Point(411, 38);
            this.edtTransitBarcode.Name = "edtTransitBarcode";
            this.edtTransitBarcode.Size = new System.Drawing.Size(82, 21);
            this.edtTransitBarcode.TabIndex = 25;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(416, 20);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(41, 12);
            this.label36.TabIndex = 24;
            this.label36.Text = "条形码";
            // 
            // edt_Password
            // 
            this.edt_Password.Location = new System.Drawing.Point(326, 37);
            this.edt_Password.Name = "edt_Password";
            this.edt_Password.Size = new System.Drawing.Size(79, 21);
            this.edt_Password.TabIndex = 23;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(326, 20);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(29, 12);
            this.label30.TabIndex = 22;
            this.label30.Text = "密码";
            // 
            // edt_User
            // 
            this.edt_User.Location = new System.Drawing.Point(210, 36);
            this.edt_User.Name = "edt_User";
            this.edt_User.Size = new System.Drawing.Size(93, 21);
            this.edt_User.TabIndex = 21;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(213, 20);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(41, 12);
            this.label31.TabIndex = 20;
            this.label31.Text = "用户名";
            // 
            // edt_ServerIP
            // 
            this.edt_ServerIP.Location = new System.Drawing.Point(10, 37);
            this.edt_ServerIP.Name = "edt_ServerIP";
            this.edt_ServerIP.Size = new System.Drawing.Size(91, 21);
            this.edt_ServerIP.TabIndex = 3;
            // 
            // edt_ServerPort
            // 
            this.edt_ServerPort.Location = new System.Drawing.Point(121, 37);
            this.edt_ServerPort.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.edt_ServerPort.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.edt_ServerPort.Name = "edt_ServerPort";
            this.edt_ServerPort.Size = new System.Drawing.Size(73, 21);
            this.edt_ServerPort.TabIndex = 2;
            this.edt_ServerPort.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(119, 17);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(29, 12);
            this.label32.TabIndex = 1;
            this.label32.Text = "端口";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(8, 17);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(41, 12);
            this.label33.TabIndex = 0;
            this.label33.Text = "IP地址";
            // 
            // grp_Savefile
            // 
            this.grp_Savefile.Controls.Add(this.edt_SaveFile);
            this.grp_Savefile.Controls.Add(this.label29);
            this.grp_Savefile.Location = new System.Drawing.Point(3, 62);
            this.grp_Savefile.Name = "grp_Savefile";
            this.grp_Savefile.Size = new System.Drawing.Size(697, 64);
            this.grp_Savefile.TabIndex = 22;
            this.grp_Savefile.TabStop = false;
            this.grp_Savefile.Text = "命令保存文件名称";
            // 
            // edt_SaveFile
            // 
            this.edt_SaveFile.Location = new System.Drawing.Point(143, 19);
            this.edt_SaveFile.Name = "edt_SaveFile";
            this.edt_SaveFile.Size = new System.Drawing.Size(542, 21);
            this.edt_SaveFile.TabIndex = 1;
            this.edt_SaveFile.Text = "curCommandData.dat";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(24, 24);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(101, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "命令保存文件名称";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "所有支持文件|*.txt;*.bmp";
            // 
            // mmo_FunResultInfo
            // 
            this.mmo_FunResultInfo.Location = new System.Drawing.Point(0, 649);
            this.mmo_FunResultInfo.Name = "mmo_FunResultInfo";
            this.mmo_FunResultInfo.Size = new System.Drawing.Size(700, 73);
            this.mmo_FunResultInfo.TabIndex = 38;
            this.mmo_FunResultInfo.Text = "";
            this.mmo_FunResultInfo.TextChanged += new System.EventHandler(this.mmo_FunResultInfo_TextChanged);
            // 
            // grp_AddDYAreaFile
            // 
            this.grp_AddDYAreaFile.Controls.Add(this.numericUpDown1);
            this.grp_AddDYAreaFile.Controls.Add(this.label35);
            this.grp_AddDYAreaFile.Controls.Add(this.tabControl1);
            this.grp_AddDYAreaFile.Controls.Add(this.chk_SingleLine);
            this.grp_AddDYAreaFile.Controls.Add(this.btn_UpDateDYArea);
            this.grp_AddDYAreaFile.Controls.Add(this.tlbtn_DelFile);
            this.grp_AddDYAreaFile.Controls.Add(this.spnedt_DYAreaShowTime);
            this.grp_AddDYAreaFile.Controls.Add(this.spnedt_DYAreaRunSpeed);
            this.grp_AddDYAreaFile.Controls.Add(this.cbb_DYAreaStunt);
            this.grp_AddDYAreaFile.Controls.Add(this.label28);
            this.grp_AddDYAreaFile.Controls.Add(this.btn_DeleteAllDYArea);
            this.grp_AddDYAreaFile.Controls.Add(this.label27);
            this.grp_AddDYAreaFile.Controls.Add(this.btn_DeleteScreenDynamicAreas);
            this.grp_AddDYAreaFile.Controls.Add(this.label26);
            this.grp_AddDYAreaFile.Location = new System.Drawing.Point(3, 438);
            this.grp_AddDYAreaFile.Name = "grp_AddDYAreaFile";
            this.grp_AddDYAreaFile.Size = new System.Drawing.Size(700, 164);
            this.grp_AddDYAreaFile.TabIndex = 37;
            this.grp_AddDYAreaFile.TabStop = false;
            this.grp_AddDYAreaFile.Text = "第四步-----动态区域文件属性";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(459, 51);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(38, 21);
            this.numericUpDown1.TabIndex = 30;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(381, 55);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(77, 12);
            this.label35.TabIndex = 29;
            this.label35.Text = "当前文件序号";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 15);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(367, 100);
            this.tabControl1.TabIndex = 28;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button7);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(359, 74);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "添加文件";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(186, 48);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(166, 23);
            this.button7.TabIndex = 3;
            this.button7.Text = "添加文件到当前动态区域";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(327, 26);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(26, 23);
            this.button6.TabIndex = 2;
            this.button6.Text = "file";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(60, 26);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(263, 21);
            this.textBox1.TabIndex = 1;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 31);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(53, 12);
            this.label34.TabIndex = 0;
            this.label34.Text = "文件名称";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.richTextBox1);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(359, 74);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "添加文本";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(3, 6);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(353, 37);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(207, 48);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(146, 23);
            this.button8.TabIndex = 0;
            this.button8.Text = "添加文本到当前动态区域";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // chk_SingleLine
            // 
            this.chk_SingleLine.AutoSize = true;
            this.chk_SingleLine.Location = new System.Drawing.Point(387, 15);
            this.chk_SingleLine.Name = "chk_SingleLine";
            this.chk_SingleLine.Size = new System.Drawing.Size(72, 16);
            this.chk_SingleLine.TabIndex = 2;
            this.chk_SingleLine.Text = "单行显示";
            this.chk_SingleLine.UseVisualStyleBackColor = true;
            // 
            // btn_UpDateDYArea
            // 
            this.btn_UpDateDYArea.Location = new System.Drawing.Point(222, 129);
            this.btn_UpDateDYArea.Name = "btn_UpDateDYArea";
            this.btn_UpDateDYArea.Size = new System.Drawing.Size(145, 23);
            this.btn_UpDateDYArea.TabIndex = 20;
            this.btn_UpDateDYArea.Text = "更新动态区域信息";
            this.btn_UpDateDYArea.UseVisualStyleBackColor = true;
            this.btn_UpDateDYArea.Click += new System.EventHandler(this.btn_UpDateDYArea_Click);
            // 
            // tlbtn_DelFile
            // 
            this.tlbtn_DelFile.Location = new System.Drawing.Point(385, 78);
            this.tlbtn_DelFile.Name = "tlbtn_DelFile";
            this.tlbtn_DelFile.Size = new System.Drawing.Size(110, 23);
            this.tlbtn_DelFile.TabIndex = 1;
            this.tlbtn_DelFile.Text = "删除系统当前文件";
            this.tlbtn_DelFile.UseVisualStyleBackColor = true;
            this.tlbtn_DelFile.Click += new System.EventHandler(this.tlbtn_DelFile_Click);
            // 
            // spnedt_DYAreaShowTime
            // 
            this.spnedt_DYAreaShowTime.Location = new System.Drawing.Point(560, 99);
            this.spnedt_DYAreaShowTime.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.spnedt_DYAreaShowTime.Name = "spnedt_DYAreaShowTime";
            this.spnedt_DYAreaShowTime.Size = new System.Drawing.Size(134, 21);
            this.spnedt_DYAreaShowTime.TabIndex = 7;
            this.spnedt_DYAreaShowTime.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // spnedt_DYAreaRunSpeed
            // 
            this.spnedt_DYAreaRunSpeed.Location = new System.Drawing.Point(560, 73);
            this.spnedt_DYAreaRunSpeed.Maximum = new decimal(new int[] {
            63,
            0,
            0,
            0});
            this.spnedt_DYAreaRunSpeed.Name = "spnedt_DYAreaRunSpeed";
            this.spnedt_DYAreaRunSpeed.Size = new System.Drawing.Size(134, 21);
            this.spnedt_DYAreaRunSpeed.TabIndex = 6;
            // 
            // cbb_DYAreaStunt
            // 
            this.cbb_DYAreaStunt.FormattingEnabled = true;
            this.cbb_DYAreaStunt.Items.AddRange(new object[] {
            "0 –随机显示",
            "1 –静止显示 ",
            "2 –快速打出 ",
            "3 –向左移动 ",
            "4 –向左连移 ",
            "5 –向上移动 ",
            "6 –向上连移 ",
            "7 –闪烁 ",
            "8 –飘雪 ",
            "9 –冒泡 ",
            "10 –中间移出 ",
            "11 –左右移入 ",
            "12 –左右交叉移入 ",
            "13 –上下交叉移入 ",
            "14 –画卷闭合 ",
            "15 –画卷打开 ",
            "16 –向左拉伸 ",
            "17 –向右拉伸 ",
            "18 –向上拉伸 ",
            "19 –向下拉伸 ",
            "20 –向左镭射 ",
            "21 –向右镭射 ",
            "22 –向上镭射 ",
            "23 –向下镭射 ",
            "24 –左右交叉拉幕 ",
            "25 –上下交叉拉幕 ",
            "26 –分散左拉 ",
            "27 –水平百页 ",
            "28 –垂直百页 ",
            "29 –向左拉幕 ",
            "30 –向右拉幕 ",
            "31 –向上拉幕 ",
            "32 –向下拉幕 ",
            "33 –左右闭合 ",
            "34 –左右对开 ",
            "35 –上下闭合 ",
            "36 –上下对开 ",
            "37 –向右移动 ",
            "38 –向右连移 ",
            "39 –向下移动 ",
            "40 –向下连移 "});
            this.cbb_DYAreaStunt.Location = new System.Drawing.Point(560, 47);
            this.cbb_DYAreaStunt.Name = "cbb_DYAreaStunt";
            this.cbb_DYAreaStunt.Size = new System.Drawing.Size(135, 20);
            this.cbb_DYAreaStunt.TabIndex = 5;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(503, 103);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 12);
            this.label28.TabIndex = 4;
            this.label28.Text = "停留时间";
            // 
            // btn_DeleteAllDYArea
            // 
            this.btn_DeleteAllDYArea.Location = new System.Drawing.Point(547, 129);
            this.btn_DeleteAllDYArea.Name = "btn_DeleteAllDYArea";
            this.btn_DeleteAllDYArea.Size = new System.Drawing.Size(145, 23);
            this.btn_DeleteAllDYArea.TabIndex = 27;
            this.btn_DeleteAllDYArea.Text = "删除所有动态区域";
            this.btn_DeleteAllDYArea.UseVisualStyleBackColor = true;
            this.btn_DeleteAllDYArea.Click += new System.EventHandler(this.button3_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(503, 77);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(53, 12);
            this.label27.TabIndex = 3;
            this.label27.Text = "运行速度";
            // 
            // btn_DeleteScreenDynamicAreas
            // 
            this.btn_DeleteScreenDynamicAreas.Location = new System.Drawing.Point(387, 129);
            this.btn_DeleteScreenDynamicAreas.Name = "btn_DeleteScreenDynamicAreas";
            this.btn_DeleteScreenDynamicAreas.Size = new System.Drawing.Size(145, 23);
            this.btn_DeleteScreenDynamicAreas.TabIndex = 26;
            this.btn_DeleteScreenDynamicAreas.Text = "删除当前动态区域";
            this.btn_DeleteScreenDynamicAreas.UseVisualStyleBackColor = true;
            this.btn_DeleteScreenDynamicAreas.Click += new System.EventHandler(this.button5_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(503, 51);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 12);
            this.label26.TabIndex = 2;
            this.label26.Text = "特技";
            // 
            // grp_AddDynamicArea
            // 
            this.grp_AddDynamicArea.Controls.Add(this.button4);
            this.grp_AddDynamicArea.Controls.Add(this.groupBox2);
            this.grp_AddDynamicArea.Controls.Add(this.cbb_PlayPriority);
            this.grp_AddDynamicArea.Controls.Add(this.label19);
            this.grp_AddDynamicArea.Controls.Add(this.grp_DYAreaF);
            this.grp_AddDynamicArea.Controls.Add(this.cbb_RunMode);
            this.grp_AddDynamicArea.Controls.Add(this.spnedt_TimeOut);
            this.grp_AddDynamicArea.Controls.Add(this.spnedt_DYAreaH);
            this.grp_AddDynamicArea.Controls.Add(this.spnedt_DYAreaW);
            this.grp_AddDynamicArea.Controls.Add(this.spnedt_DYAreaY);
            this.grp_AddDynamicArea.Controls.Add(this.spnedt_DYAreaX);
            this.grp_AddDynamicArea.Controls.Add(this.spnedt_DYAreaID);
            this.grp_AddDynamicArea.Controls.Add(this.label18);
            this.grp_AddDynamicArea.Controls.Add(this.label17);
            this.grp_AddDynamicArea.Controls.Add(this.label16);
            this.grp_AddDynamicArea.Controls.Add(this.label15);
            this.grp_AddDynamicArea.Controls.Add(this.label14);
            this.grp_AddDynamicArea.Controls.Add(this.label13);
            this.grp_AddDynamicArea.Controls.Add(this.label12);
            this.grp_AddDynamicArea.Location = new System.Drawing.Point(3, 210);
            this.grp_AddDynamicArea.Name = "grp_AddDynamicArea";
            this.grp_AddDynamicArea.Size = new System.Drawing.Size(700, 222);
            this.grp_AddDynamicArea.TabIndex = 35;
            this.grp_AddDynamicArea.TabStop = false;
            this.grp_AddDynamicArea.Text = "第三步-----添加动态区域";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(492, 194);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(202, 23);
            this.button4.TabIndex = 19;
            this.button4.Text = "添加屏幕动态区域";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.edt_RelatePro);
            this.groupBox2.Controls.Add(this.radbtn_SelRelatePro);
            this.groupBox2.Controls.Add(this.radbtn_AllRelatePro);
            this.groupBox2.Controls.Add(this.radbtn_NoRelate);
            this.groupBox2.Location = new System.Drawing.Point(3, 139);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(697, 49);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "动态区域关联节目";
            // 
            // edt_RelatePro
            // 
            this.edt_RelatePro.Location = new System.Drawing.Point(520, 17);
            this.edt_RelatePro.Name = "edt_RelatePro";
            this.edt_RelatePro.Size = new System.Drawing.Size(169, 21);
            this.edt_RelatePro.TabIndex = 8;
            // 
            // radbtn_SelRelatePro
            // 
            this.radbtn_SelRelatePro.AutoSize = true;
            this.radbtn_SelRelatePro.Location = new System.Drawing.Point(254, 13);
            this.radbtn_SelRelatePro.Name = "radbtn_SelRelatePro";
            this.radbtn_SelRelatePro.Size = new System.Drawing.Size(269, 28);
            this.radbtn_SelRelatePro.TabIndex = 7;
            this.radbtn_SelRelatePro.Text = "在指定节目中显示(节目编号间用\",\"隔开,节目\r\n编号定义为LedshowTW软件中\"P***\"中的\"***\")";
            this.radbtn_SelRelatePro.UseVisualStyleBackColor = true;
            // 
            // radbtn_AllRelatePro
            // 
            this.radbtn_AllRelatePro.AutoSize = true;
            this.radbtn_AllRelatePro.Location = new System.Drawing.Point(117, 19);
            this.radbtn_AllRelatePro.Name = "radbtn_AllRelatePro";
            this.radbtn_AllRelatePro.Size = new System.Drawing.Size(131, 16);
            this.radbtn_AllRelatePro.TabIndex = 6;
            this.radbtn_AllRelatePro.Text = "所有节目显示该区域";
            this.radbtn_AllRelatePro.UseVisualStyleBackColor = true;
            // 
            // radbtn_NoRelate
            // 
            this.radbtn_NoRelate.AutoSize = true;
            this.radbtn_NoRelate.Checked = true;
            this.radbtn_NoRelate.Location = new System.Drawing.Point(4, 19);
            this.radbtn_NoRelate.Name = "radbtn_NoRelate";
            this.radbtn_NoRelate.Size = new System.Drawing.Size(107, 16);
            this.radbtn_NoRelate.TabIndex = 5;
            this.radbtn_NoRelate.TabStop = true;
            this.radbtn_NoRelate.Text = "不关联节目显示";
            this.radbtn_NoRelate.UseVisualStyleBackColor = true;
            // 
            // cbb_PlayPriority
            // 
            this.cbb_PlayPriority.DropDownWidth = 250;
            this.cbb_PlayPriority.FormattingEnabled = true;
            this.cbb_PlayPriority.Items.AddRange(new object[] {
            "与节目一起播放(动态区关联异步节目才有效)",
            "节目停止播放，仅播放该动态区域"});
            this.cbb_PlayPriority.Location = new System.Drawing.Point(572, 35);
            this.cbb_PlayPriority.Name = "cbb_PlayPriority";
            this.cbb_PlayPriority.Size = new System.Drawing.Size(121, 20);
            this.cbb_PlayPriority.TabIndex = 17;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(572, 20);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 12);
            this.label19.TabIndex = 16;
            this.label19.Text = "播放优先级";
            // 
            // grp_DYAreaF
            // 
            this.grp_DYAreaF.Controls.Add(this.spnedt_DYAreaFMoveStep);
            this.grp_DYAreaF.Controls.Add(this.label25);
            this.grp_DYAreaF.Controls.Add(this.spnedt_DYAreaFRunSpeed);
            this.grp_DYAreaF.Controls.Add(this.label24);
            this.grp_DYAreaF.Controls.Add(this.cbb_DYAreaFStunt);
            this.grp_DYAreaF.Controls.Add(this.label23);
            this.grp_DYAreaF.Controls.Add(this.spnedt_DYAreaFMuli);
            this.grp_DYAreaF.Controls.Add(this.spnedt_DYAreaFSingleColor);
            this.grp_DYAreaF.Controls.Add(this.spnedt_DYAreaFSingle);
            this.grp_DYAreaF.Controls.Add(this.label22);
            this.grp_DYAreaF.Controls.Add(this.radbtn_DYAreaFMuli);
            this.grp_DYAreaF.Controls.Add(this.label21);
            this.grp_DYAreaF.Controls.Add(this.label20);
            this.grp_DYAreaF.Controls.Add(this.radbtn_DYAreaFSingle);
            this.grp_DYAreaF.Controls.Add(this.chk_DYAreaF);
            this.grp_DYAreaF.Location = new System.Drawing.Point(3, 67);
            this.grp_DYAreaF.Name = "grp_DYAreaF";
            this.grp_DYAreaF.Size = new System.Drawing.Size(697, 70);
            this.grp_DYAreaF.TabIndex = 15;
            this.grp_DYAreaF.TabStop = false;
            // 
            // spnedt_DYAreaFMoveStep
            // 
            this.spnedt_DYAreaFMoveStep.Location = new System.Drawing.Point(636, 38);
            this.spnedt_DYAreaFMoveStep.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.spnedt_DYAreaFMoveStep.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnedt_DYAreaFMoveStep.Name = "spnedt_DYAreaFMoveStep";
            this.spnedt_DYAreaFMoveStep.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaFMoveStep.TabIndex = 15;
            this.spnedt_DYAreaFMoveStep.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(636, 18);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 12);
            this.label25.TabIndex = 14;
            this.label25.Text = "移动步长";
            // 
            // spnedt_DYAreaFRunSpeed
            // 
            this.spnedt_DYAreaFRunSpeed.Location = new System.Drawing.Point(559, 38);
            this.spnedt_DYAreaFRunSpeed.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.spnedt_DYAreaFRunSpeed.Name = "spnedt_DYAreaFRunSpeed";
            this.spnedt_DYAreaFRunSpeed.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaFRunSpeed.TabIndex = 13;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(559, 18);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 12);
            this.label24.TabIndex = 12;
            this.label24.Text = "运行速度";
            // 
            // cbb_DYAreaFStunt
            // 
            this.cbb_DYAreaFStunt.FormattingEnabled = true;
            this.cbb_DYAreaFStunt.Items.AddRange(new object[] {
            "0-闪烁 ",
            "1 –顺时针转动 ",
            "2 –逆时针转动 ",
            "3 –闪烁加顺时针转动 ",
            "4 –闪烁加逆时针转动 ",
            "5 –红绿交替闪烁 ",
            "6 –红绿交替转动 ",
            "7 –静止打出"});
            this.cbb_DYAreaFStunt.Location = new System.Drawing.Point(325, 38);
            this.cbb_DYAreaFStunt.Name = "cbb_DYAreaFStunt";
            this.cbb_DYAreaFStunt.Size = new System.Drawing.Size(211, 20);
            this.cbb_DYAreaFStunt.TabIndex = 11;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(325, 18);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 10;
            this.label23.Text = "边框特技";
            // 
            // spnedt_DYAreaFMuli
            // 
            this.spnedt_DYAreaFMuli.Location = new System.Drawing.Point(242, 38);
            this.spnedt_DYAreaFMuli.Maximum = new decimal(new int[] {
            46,
            0,
            0,
            0});
            this.spnedt_DYAreaFMuli.Name = "spnedt_DYAreaFMuli";
            this.spnedt_DYAreaFMuli.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaFMuli.TabIndex = 9;
            // 
            // spnedt_DYAreaFSingleColor
            // 
            this.spnedt_DYAreaFSingleColor.Location = new System.Drawing.Point(120, 38);
            this.spnedt_DYAreaFSingleColor.Maximum = new decimal(new int[] {
            16777215,
            0,
            0,
            0});
            this.spnedt_DYAreaFSingleColor.Name = "spnedt_DYAreaFSingleColor";
            this.spnedt_DYAreaFSingleColor.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaFSingleColor.TabIndex = 8;
            this.spnedt_DYAreaFSingleColor.Value = new decimal(new int[] {
            255,
            0,
            0,
            0});
            // 
            // spnedt_DYAreaFSingle
            // 
            this.spnedt_DYAreaFSingle.Location = new System.Drawing.Point(56, 38);
            this.spnedt_DYAreaFSingle.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.spnedt_DYAreaFSingle.Name = "spnedt_DYAreaFSingle";
            this.spnedt_DYAreaFSingle.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaFSingle.TabIndex = 7;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(242, 18);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 12);
            this.label22.TabIndex = 5;
            this.label22.Text = "边框类型";
            // 
            // radbtn_DYAreaFMuli
            // 
            this.radbtn_DYAreaFMuli.AutoSize = true;
            this.radbtn_DYAreaFMuli.Location = new System.Drawing.Point(194, 40);
            this.radbtn_DYAreaFMuli.Name = "radbtn_DYAreaFMuli";
            this.radbtn_DYAreaFMuli.Size = new System.Drawing.Size(47, 16);
            this.radbtn_DYAreaFMuli.TabIndex = 4;
            this.radbtn_DYAreaFMuli.Text = "花色";
            this.radbtn_DYAreaFMuli.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(120, 18);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 3;
            this.label21.Text = "显示颜色";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(56, 18);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 2;
            this.label20.Text = "边框类型";
            // 
            // radbtn_DYAreaFSingle
            // 
            this.radbtn_DYAreaFSingle.AutoSize = true;
            this.radbtn_DYAreaFSingle.Checked = true;
            this.radbtn_DYAreaFSingle.Location = new System.Drawing.Point(7, 40);
            this.radbtn_DYAreaFSingle.Name = "radbtn_DYAreaFSingle";
            this.radbtn_DYAreaFSingle.Size = new System.Drawing.Size(47, 16);
            this.radbtn_DYAreaFSingle.TabIndex = 1;
            this.radbtn_DYAreaFSingle.TabStop = true;
            this.radbtn_DYAreaFSingle.Text = "纯色";
            this.radbtn_DYAreaFSingle.UseVisualStyleBackColor = true;
            // 
            // chk_DYAreaF
            // 
            this.chk_DYAreaF.AutoSize = true;
            this.chk_DYAreaF.Location = new System.Drawing.Point(3, -1);
            this.chk_DYAreaF.Name = "chk_DYAreaF";
            this.chk_DYAreaF.Size = new System.Drawing.Size(96, 16);
            this.chk_DYAreaF.TabIndex = 0;
            this.chk_DYAreaF.Text = "显示区域边框";
            this.chk_DYAreaF.UseVisualStyleBackColor = true;
            // 
            // cbb_RunMode
            // 
            this.cbb_RunMode.DropDownWidth = 250;
            this.cbb_RunMode.FormattingEnabled = true;
            this.cbb_RunMode.Items.AddRange(new object[] {
            "动态区数据循环显示",
            "显示完成后静止显示最后一页",
            "超时后未更新删除动态区",
            "顺序显示完成最后页后就不再显示 "});
            this.cbb_RunMode.Location = new System.Drawing.Point(354, 35);
            this.cbb_RunMode.Name = "cbb_RunMode";
            this.cbb_RunMode.Size = new System.Drawing.Size(121, 20);
            this.cbb_RunMode.TabIndex = 13;
            // 
            // spnedt_TimeOut
            // 
            this.spnedt_TimeOut.Location = new System.Drawing.Point(489, 35);
            this.spnedt_TimeOut.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.spnedt_TimeOut.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnedt_TimeOut.Name = "spnedt_TimeOut";
            this.spnedt_TimeOut.Size = new System.Drawing.Size(69, 21);
            this.spnedt_TimeOut.TabIndex = 12;
            this.spnedt_TimeOut.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // spnedt_DYAreaH
            // 
            this.spnedt_DYAreaH.Location = new System.Drawing.Point(286, 35);
            this.spnedt_DYAreaH.Maximum = new decimal(new int[] {
            512,
            0,
            0,
            0});
            this.spnedt_DYAreaH.Minimum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.spnedt_DYAreaH.Name = "spnedt_DYAreaH";
            this.spnedt_DYAreaH.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaH.TabIndex = 11;
            this.spnedt_DYAreaH.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // spnedt_DYAreaW
            // 
            this.spnedt_DYAreaW.Location = new System.Drawing.Point(218, 35);
            this.spnedt_DYAreaW.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.spnedt_DYAreaW.Minimum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.spnedt_DYAreaW.Name = "spnedt_DYAreaW";
            this.spnedt_DYAreaW.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaW.TabIndex = 10;
            this.spnedt_DYAreaW.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // spnedt_DYAreaY
            // 
            this.spnedt_DYAreaY.Location = new System.Drawing.Point(150, 35);
            this.spnedt_DYAreaY.Maximum = new decimal(new int[] {
            512,
            0,
            0,
            0});
            this.spnedt_DYAreaY.Name = "spnedt_DYAreaY";
            this.spnedt_DYAreaY.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaY.TabIndex = 9;
            // 
            // spnedt_DYAreaX
            // 
            this.spnedt_DYAreaX.Location = new System.Drawing.Point(82, 35);
            this.spnedt_DYAreaX.Maximum = new decimal(new int[] {
            8192,
            0,
            0,
            0});
            this.spnedt_DYAreaX.Name = "spnedt_DYAreaX";
            this.spnedt_DYAreaX.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaX.TabIndex = 8;
            // 
            // spnedt_DYAreaID
            // 
            this.spnedt_DYAreaID.Location = new System.Drawing.Point(5, 35);
            this.spnedt_DYAreaID.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.spnedt_DYAreaID.Name = "spnedt_DYAreaID";
            this.spnedt_DYAreaID.Size = new System.Drawing.Size(54, 21);
            this.spnedt_DYAreaID.TabIndex = 7;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(489, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 12);
            this.label18.TabIndex = 6;
            this.label18.Text = "超时时间(秒)";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(354, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 5;
            this.label17.Text = "运行模式";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(286, 19);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 4;
            this.label16.Text = "高度";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(218, 19);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(29, 12);
            this.label15.TabIndex = 3;
            this.label15.Text = "宽度";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(150, 19);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(11, 12);
            this.label14.TabIndex = 2;
            this.label14.Text = "Y";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(82, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(11, 12);
            this.label13.TabIndex = 1;
            this.label13.Text = "X";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(5, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "动态区域编号";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button12);
            this.groupBox3.Controls.Add(this.button9);
            this.groupBox3.Location = new System.Drawing.Point(3, 608);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(699, 35);
            this.groupBox3.TabIndex = 39;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "第五步-----释放动态库";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(150, 12);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(106, 23);
            this.button12.TabIndex = 1;
            this.button12.Text = "退出程序";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(18, 12);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(109, 23);
            this.button9.TabIndex = 0;
            this.button9.Text = "释放动态库";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Location = new System.Drawing.Point(2, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(698, 41);
            this.groupBox4.TabIndex = 40;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "第一步-----初始化动态库";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(13, 12);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(115, 23);
            this.button10.TabIndex = 0;
            this.button10.Text = "初始化动态库";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(606, 19);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(53, 12);
            this.label38.TabIndex = 26;
            this.label38.Text = "通信协议";
            // 
            // cbb_StaticIpMode
            // 
            this.cbb_StaticIpMode.FormattingEnabled = true;
            this.cbb_StaticIpMode.Items.AddRange(new object[] {
            "TCP模式",
            "UDP模式"});
            this.cbb_StaticIpMode.Location = new System.Drawing.Point(603, 36);
            this.cbb_StaticIpMode.Name = "cbb_StaticIpMode";
            this.cbb_StaticIpMode.Size = new System.Drawing.Size(85, 20);
            this.cbb_StaticIpMode.TabIndex = 27;
            this.cbb_StaticIpMode.Text = "TCP模式";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 718);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.mmo_FunResultInfo);
            this.Controls.Add(this.grp_AddDYAreaFile);
            this.Controls.Add(this.grp_AddDynamicArea);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "C_Sharp_Demo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.grp_Network.ResumeLayout(false);
            this.grp_Network.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_StaticIP_Port)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_Height)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_Width)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_PNo)).EndInit();
            this.grp_SerialPort.ResumeLayout(false);
            this.grp_SerialPort.PerformLayout();
            this.grp_Server.ResumeLayout(false);
            this.grp_Server.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edt_ServerPort)).EndInit();
            this.grp_Savefile.ResumeLayout(false);
            this.grp_Savefile.PerformLayout();
            this.grp_AddDYAreaFile.ResumeLayout(false);
            this.grp_AddDYAreaFile.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaShowTime)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaRunSpeed)).EndInit();
            this.grp_AddDynamicArea.ResumeLayout(false);
            this.grp_AddDynamicArea.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grp_DYAreaF.ResumeLayout(false);
            this.grp_DYAreaF.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFMoveStep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFRunSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFMuli)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFSingleColor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaFSingle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_TimeOut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_DYAreaID)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbb_Pixel;
        private System.Windows.Forms.ComboBox cbb_Color;
        private System.Windows.Forms.NumericUpDown spnedt_Height;
        private System.Windows.Forms.NumericUpDown spnedt_Width;
        private System.Windows.Forms.ComboBox cbb_SendMode;
        private System.Windows.Forms.ComboBox cbb_ControllerType;
        private System.Windows.Forms.NumericUpDown spnedt_PNo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grp_SerialPort;
        private System.Windows.Forms.ComboBox cbb_Baud;
        private System.Windows.Forms.ComboBox cbb_Comm;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.GroupBox grp_Server;
        private System.Windows.Forms.TextBox edt_User;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox edt_ServerIP;
        private System.Windows.Forms.NumericUpDown edt_ServerPort;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.TextBox edt_Password;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RichTextBox mmo_FunResultInfo;
        private System.Windows.Forms.GroupBox grp_AddDYAreaFile;
        private System.Windows.Forms.Button btn_UpDateDYArea;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaShowTime;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaRunSpeed;
        private System.Windows.Forms.ComboBox cbb_DYAreaStunt;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Button btn_DeleteAllDYArea;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btn_DeleteScreenDynamicAreas;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.CheckBox chk_SingleLine;
        private System.Windows.Forms.Button tlbtn_DelFile;
        private System.Windows.Forms.GroupBox grp_AddDynamicArea;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox edt_RelatePro;
        private System.Windows.Forms.RadioButton radbtn_SelRelatePro;
        private System.Windows.Forms.RadioButton radbtn_AllRelatePro;
        private System.Windows.Forms.RadioButton radbtn_NoRelate;
        private System.Windows.Forms.ComboBox cbb_PlayPriority;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox grp_DYAreaF;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaFMoveStep;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaFRunSpeed;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cbb_DYAreaFStunt;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaFMuli;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaFSingleColor;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaFSingle;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RadioButton radbtn_DYAreaFMuli;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RadioButton radbtn_DYAreaFSingle;
        private System.Windows.Forms.CheckBox chk_DYAreaF;
        private System.Windows.Forms.ComboBox cbb_RunMode;
        private System.Windows.Forms.NumericUpDown spnedt_TimeOut;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaH;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaW;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaY;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaX;
        private System.Windows.Forms.NumericUpDown spnedt_DYAreaID;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox grp_Savefile;
        private System.Windows.Forms.TextBox edt_SaveFile;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.GroupBox grp_Network;
        private System.Windows.Forms.RadioButton radbtn_ServerMode;
        private System.Windows.Forms.RadioButton radbtn_FixIPMode;
        private System.Windows.Forms.TextBox edt_NetworkID;
        private System.Windows.Forms.Label lbl_NetworkID;
        private System.Windows.Forms.TextBox edt_StaticIP_IP;
        private System.Windows.Forms.NumericUpDown spnedt_StaticIP_Port;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox edtTransitNetworkID;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox edtTransitBarcode;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.ComboBox cbb_StaticIpMode;
        private System.Windows.Forms.Label label38;
    }
}

