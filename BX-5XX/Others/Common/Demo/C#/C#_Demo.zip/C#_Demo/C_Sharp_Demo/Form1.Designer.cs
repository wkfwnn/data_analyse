﻿namespace C_Sharp_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label11;
            this.grp_GPRS = new System.Windows.Forms.GroupBox();
            this.button38 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.edt_GprsID = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.comb_GprsStyle = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.edt_GprsPort = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.edt_GprsIP = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.grp_Server = new System.Windows.Forms.GroupBox();
            this.edtTransitNetworkID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.edtTransitBarcode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.grp_Network = new System.Windows.Forms.GroupBox();
            this.button41 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.radbtn_ServerMode = new System.Windows.Forms.RadioButton();
            this.radbtn_FixIPMode = new System.Windows.Forms.RadioButton();
            this.grp_SerialPort = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.spnedt_Height = new System.Windows.Forms.NumericUpDown();
            this.spnedt_Width = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.nSendMode = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.spnedt_ScreenNo = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.spnedt_curProgramOrd = new System.Windows.Forms.NumericUpDown();
            this.label12 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.Alignment = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.button34 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.spnedt_curFileOrd = new System.Windows.Forms.NumericUpDown();
            this.button20 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button30 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button31 = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button32 = new System.Windows.Forms.Button();
            this.spnedt_curAreaOrd = new System.Windows.Forms.NumericUpDown();
            this.label15 = new System.Windows.Forms.Label();
            this.rchMessage = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button35 = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.btnQueryScreenParameter = new System.Windows.Forms.Button();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button39 = new System.Windows.Forms.Button();
            this.grp_wifi = new System.Windows.Forms.GroupBox();
            this.btnWiFiStopServer = new System.Windows.Forms.Button();
            this.btnWiFiStartServer = new System.Windows.Forms.Button();
            this.tbWiFiNetID = new System.Windows.Forms.TextBox();
            this.lbWiFiNetID = new System.Windows.Forms.Label();
            this.numWiFiPort = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.tbWiFiIp = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.rdbWiFiServerMode = new System.Windows.Forms.RadioButton();
            this.rdbWiFiFixMode = new System.Windows.Forms.RadioButton();
            this.label30 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            label11 = new System.Windows.Forms.Label();
            this.grp_GPRS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edt_GprsPort)).BeginInit();
            this.grp_Server.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            this.grp_Network.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            this.grp_SerialPort.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_Height)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_Width)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_ScreenNo)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_curProgramOrd)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_curFileOrd)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_curAreaOrd)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grp_wifi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numWiFiPort)).BeginInit();
            this.SuspendLayout();
            // 
            // label11
            // 
            label11.AutoEllipsis = true;
            label11.AutoSize = true;
            label11.ForeColor = System.Drawing.Color.Crimson;
            label11.Location = new System.Drawing.Point(9, 126);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(389, 24);
            label11.TabIndex = 19;
            label11.Text = "注意：M、E系列才支持网络方式通讯;BX-4M只支持三基色；其余类型控制\r\n卡都不支持三基色；BX-3T只支持9600波特率";
            // 
            // grp_GPRS
            // 
            this.grp_GPRS.Controls.Add(this.button38);
            this.grp_GPRS.Controls.Add(this.button37);
            this.grp_GPRS.Controls.Add(this.edt_GprsID);
            this.grp_GPRS.Controls.Add(this.label28);
            this.grp_GPRS.Controls.Add(this.comb_GprsStyle);
            this.grp_GPRS.Controls.Add(this.label27);
            this.grp_GPRS.Controls.Add(this.edt_GprsPort);
            this.grp_GPRS.Controls.Add(this.label26);
            this.grp_GPRS.Controls.Add(this.edt_GprsIP);
            this.grp_GPRS.Controls.Add(this.label25);
            this.grp_GPRS.Location = new System.Drawing.Point(3, 59);
            this.grp_GPRS.Name = "grp_GPRS";
            this.grp_GPRS.Size = new System.Drawing.Size(748, 64);
            this.grp_GPRS.TabIndex = 8;
            this.grp_GPRS.TabStop = false;
            this.grp_GPRS.Text = "GPRS设置";
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(541, 38);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(95, 23);
            this.button38.TabIndex = 9;
            this.button38.Text = "关闭服务器";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(438, 38);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(96, 23);
            this.button37.TabIndex = 8;
            this.button37.Text = "启动服务器";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // edt_GprsID
            // 
            this.edt_GprsID.Location = new System.Drawing.Point(336, 38);
            this.edt_GprsID.Name = "edt_GprsID";
            this.edt_GprsID.Size = new System.Drawing.Size(95, 21);
            this.edt_GprsID.TabIndex = 7;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(340, 19);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(53, 12);
            this.label28.TabIndex = 6;
            this.label28.Text = "GPRS编号";
            // 
            // comb_GprsStyle
            // 
            this.comb_GprsStyle.FormattingEnabled = true;
            this.comb_GprsStyle.Items.AddRange(new object[] {
            "BX-GPRS"});
            this.comb_GprsStyle.Location = new System.Drawing.Point(233, 38);
            this.comb_GprsStyle.Name = "comb_GprsStyle";
            this.comb_GprsStyle.Size = new System.Drawing.Size(84, 20);
            this.comb_GprsStyle.TabIndex = 5;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(239, 19);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(53, 12);
            this.label27.TabIndex = 4;
            this.label27.Text = "GPRS类型";
            // 
            // edt_GprsPort
            // 
            this.edt_GprsPort.Location = new System.Drawing.Point(120, 37);
            this.edt_GprsPort.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.edt_GprsPort.Name = "edt_GprsPort";
            this.edt_GprsPort.Size = new System.Drawing.Size(95, 21);
            this.edt_GprsPort.TabIndex = 3;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(121, 19);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 12);
            this.label26.TabIndex = 2;
            this.label26.Text = "端口";
            // 
            // edt_GprsIP
            // 
            this.edt_GprsIP.Location = new System.Drawing.Point(13, 37);
            this.edt_GprsIP.Name = "edt_GprsIP";
            this.edt_GprsIP.Size = new System.Drawing.Size(83, 21);
            this.edt_GprsIP.TabIndex = 1;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(12, 19);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(41, 12);
            this.label25.TabIndex = 0;
            this.label25.Text = "IP地址";
            // 
            // grp_Server
            // 
            this.grp_Server.Controls.Add(this.edtTransitNetworkID);
            this.grp_Server.Controls.Add(this.label5);
            this.grp_Server.Controls.Add(this.button33);
            this.grp_Server.Controls.Add(this.edtTransitBarcode);
            this.grp_Server.Controls.Add(this.label2);
            this.grp_Server.Controls.Add(this.numericUpDown8);
            this.grp_Server.Controls.Add(this.textBox7);
            this.grp_Server.Controls.Add(this.textBox6);
            this.grp_Server.Controls.Add(this.textBox5);
            this.grp_Server.Controls.Add(this.label22);
            this.grp_Server.Controls.Add(this.label21);
            this.grp_Server.Controls.Add(this.label20);
            this.grp_Server.Controls.Add(this.label19);
            this.grp_Server.Location = new System.Drawing.Point(0, 59);
            this.grp_Server.Name = "grp_Server";
            this.grp_Server.Size = new System.Drawing.Size(748, 64);
            this.grp_Server.TabIndex = 1;
            this.grp_Server.TabStop = false;
            this.grp_Server.Text = "ONBON服务器";
            // 
            // edtTransitNetworkID
            // 
            this.edtTransitNetworkID.Location = new System.Drawing.Point(564, 34);
            this.edtTransitNetworkID.Name = "edtTransitNetworkID";
            this.edtTransitNetworkID.ReadOnly = true;
            this.edtTransitNetworkID.Size = new System.Drawing.Size(89, 21);
            this.edtTransitNetworkID.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(568, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "网络ID";
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(659, 33);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(87, 23);
            this.button33.TabIndex = 20;
            this.button33.Text = "绑定无线设备";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Visible = false;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // edtTransitBarcode
            // 
            this.edtTransitBarcode.Location = new System.Drawing.Point(458, 33);
            this.edtTransitBarcode.Name = "edtTransitBarcode";
            this.edtTransitBarcode.ReadOnly = true;
            this.edtTransitBarcode.Size = new System.Drawing.Size(100, 21);
            this.edtTransitBarcode.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(456, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "条形码";
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.Location = new System.Drawing.Point(120, 33);
            this.numericUpDown8.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown8.Minimum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(111, 21);
            this.numericUpDown8.TabIndex = 7;
            this.numericUpDown8.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(352, 33);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 21);
            this.textBox7.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(245, 33);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 21);
            this.textBox6.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(10, 32);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 21);
            this.textBox5.TabIndex = 4;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(357, 17);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 12);
            this.label22.TabIndex = 3;
            this.label22.Text = "密码";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(247, 17);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 12);
            this.label21.TabIndex = 2;
            this.label21.Text = "用户名";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(118, 17);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 12);
            this.label20.TabIndex = 1;
            this.label20.Text = "端口";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 17);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(41, 12);
            this.label19.TabIndex = 0;
            this.label19.Text = "IP地址";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "单基色",
            "双基色",
            "三基色",
            "全彩色",
            "双基色灰度"});
            this.comboBox5.Location = new System.Drawing.Point(501, 33);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(79, 20);
            this.comboBox5.TabIndex = 23;
            // 
            // grp_Network
            // 
            this.grp_Network.Controls.Add(this.button41);
            this.grp_Network.Controls.Add(this.button40);
            this.grp_Network.Controls.Add(this.textBox4);
            this.grp_Network.Controls.Add(this.label18);
            this.grp_Network.Controls.Add(this.numericUpDown7);
            this.grp_Network.Controls.Add(this.textBox3);
            this.grp_Network.Controls.Add(this.label17);
            this.grp_Network.Controls.Add(this.label16);
            this.grp_Network.Controls.Add(this.radbtn_ServerMode);
            this.grp_Network.Controls.Add(this.radbtn_FixIPMode);
            this.grp_Network.Location = new System.Drawing.Point(3, 59);
            this.grp_Network.Name = "grp_Network";
            this.grp_Network.Size = new System.Drawing.Size(748, 64);
            this.grp_Network.TabIndex = 4;
            this.grp_Network.TabStop = false;
            this.grp_Network.Text = "网络串口";
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(396, 33);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(91, 23);
            this.button41.TabIndex = 9;
            this.button41.Text = "关闭服务器";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(298, 33);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(87, 23);
            this.button40.TabIndex = 8;
            this.button40.Text = "启动服务器";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(197, 32);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(85, 21);
            this.textBox4.TabIndex = 7;
            this.textBox4.Visible = false;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(199, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(41, 12);
            this.label18.TabIndex = 6;
            this.label18.Text = "网络ID";
            this.label18.Visible = false;
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Location = new System.Drawing.Point(114, 32);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(52, 21);
            this.numericUpDown7.TabIndex = 5;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(10, 32);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(81, 21);
            this.textBox3.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(112, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 12);
            this.label17.TabIndex = 3;
            this.label17.Text = "端口";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(8, 17);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 12);
            this.label16.TabIndex = 2;
            this.label16.Text = "IP地址";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // radbtn_ServerMode
            // 
            this.radbtn_ServerMode.AutoSize = true;
            this.radbtn_ServerMode.Location = new System.Drawing.Point(160, 0);
            this.radbtn_ServerMode.Name = "radbtn_ServerMode";
            this.radbtn_ServerMode.Size = new System.Drawing.Size(83, 16);
            this.radbtn_ServerMode.TabIndex = 1;
            this.radbtn_ServerMode.Text = "服务器模式";
            this.radbtn_ServerMode.UseVisualStyleBackColor = true;
            this.radbtn_ServerMode.CheckedChanged += new System.EventHandler(this.radbtn_ServerMode_CheckedChanged);
            // 
            // radbtn_FixIPMode
            // 
            this.radbtn_FixIPMode.AutoSize = true;
            this.radbtn_FixIPMode.Checked = true;
            this.radbtn_FixIPMode.Location = new System.Drawing.Point(63, 0);
            this.radbtn_FixIPMode.Name = "radbtn_FixIPMode";
            this.radbtn_FixIPMode.Size = new System.Drawing.Size(83, 16);
            this.radbtn_FixIPMode.TabIndex = 0;
            this.radbtn_FixIPMode.TabStop = true;
            this.radbtn_FixIPMode.Text = "固定IP模式";
            this.radbtn_FixIPMode.UseVisualStyleBackColor = true;
            this.radbtn_FixIPMode.CheckedChanged += new System.EventHandler(this.radbtn_FixIPMode_CheckedChanged);
            // 
            // grp_SerialPort
            // 
            this.grp_SerialPort.Controls.Add(this.comboBox4);
            this.grp_SerialPort.Controls.Add(this.comboBox3);
            this.grp_SerialPort.Controls.Add(this.label7);
            this.grp_SerialPort.Controls.Add(this.label6);
            this.grp_SerialPort.Location = new System.Drawing.Point(9, 59);
            this.grp_SerialPort.Name = "grp_SerialPort";
            this.grp_SerialPort.Size = new System.Drawing.Size(748, 64);
            this.grp_SerialPort.TabIndex = 9;
            this.grp_SerialPort.TabStop = false;
            this.grp_SerialPort.Text = "串口设置";
            this.grp_SerialPort.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "9600",
            "57600"});
            this.comboBox4.Location = new System.Drawing.Point(136, 35);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(95, 20);
            this.comboBox4.TabIndex = 3;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(13, 35);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(95, 20);
            this.comboBox3.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(134, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 1;
            this.label7.Text = "波特率";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "串口";
            // 
            // spnedt_Height
            // 
            this.spnedt_Height.Increment = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.spnedt_Height.Location = new System.Drawing.Point(415, 31);
            this.spnedt_Height.Maximum = new decimal(new int[] {
            512,
            0,
            0,
            0});
            this.spnedt_Height.Minimum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.spnedt_Height.Name = "spnedt_Height";
            this.spnedt_Height.Size = new System.Drawing.Size(70, 21);
            this.spnedt_Height.TabIndex = 17;
            this.spnedt_Height.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            // 
            // spnedt_Width
            // 
            this.spnedt_Width.Increment = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.spnedt_Width.Location = new System.Drawing.Point(328, 31);
            this.spnedt_Width.Maximum = new decimal(new int[] {
            4096,
            0,
            0,
            0});
            this.spnedt_Width.Minimum = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.spnedt_Width.Name = "spnedt_Width";
            this.spnedt_Width.Size = new System.Drawing.Size(69, 21);
            this.spnedt_Width.TabIndex = 16;
            this.spnedt_Width.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(499, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 12);
            this.label10.TabIndex = 15;
            this.label10.Text = "屏型";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(415, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 14;
            this.label9.Text = "高度";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(326, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 13;
            this.label8.Text = "宽度";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(661, 129);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(95, 23);
            this.button3.TabIndex = 12;
            this.button3.Text = "设置屏幕参数";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(546, 129);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "删除系统当前屏幕";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(444, 129);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "添加屏幕";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "BX_5AT",
            "BX_5A0",
            "BX_5A1",
            "BX_5A2",
            "BX_5A3",
            "BX_5A4",
            "BX_5A1_WIFI",
            "BX_5A2_WIFI",
            "BX_5A4_WIFI",
            "BX_5A",
            "BX_5A2_RF",
            "BX_5A4_RF",
            "BX_5AT_WIFI",
            "BX_5AL",
            "AX_AT",
            "AX_A0",
            "BX_5MT",
            "BX_5M1",
            "BX_5M1X",
            "BX_5M2",
            "BX_5M3",
            "BX_5M4",
            "BX_5E1",
            "BX_5E2",
            "BX_5E3",
            "BX_5UT",
            "BX_5U0",
            "BX_5U1",
            "BX_5U2",
            "BX_5U3",
            "BX_5U4",
            "BX_5U5",
            "BX_5U",
            "BX_5UL",
            "AX_UL",
            "AX_UT",
            "AX_U0",
            "AX_U1",
            "AX_U2",
            "BX_5Q0",
            "BX_5Q1",
            "BX_5Q2",
            "BX_5Q0P",
            "BX_5Q1P",
            "BX_5Q2P",
            "BX_5QL",
            "BX_5QS1",
            "BX_5QS2",
            "BX_5QS",
            "BX_5QS1P",
            "BX_5QS2P",
            "BX_5QSP"});
            this.comboBox2.Location = new System.Drawing.Point(107, 33);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(103, 20);
            this.comboBox2.TabIndex = 7;
            // 
            // nSendMode
            // 
            this.nSendMode.FormattingEnabled = true;
            this.nSendMode.Items.AddRange(new object[] {
            "串口通讯",
            "GPRS无线通讯",
            "网口通讯",
            "ONBON服务器-GPRS",
            "ONBON服务器-3G",
            "RF通讯",
            "WIFI通讯"});
            this.nSendMode.Location = new System.Drawing.Point(226, 32);
            this.nSendMode.Name = "nSendMode";
            this.nSendMode.Size = new System.Drawing.Size(82, 20);
            this.nSendMode.TabIndex = 6;
            this.nSendMode.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(224, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 5;
            this.label4.Text = "通讯模式";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(105, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "控制卡型号";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // spnedt_ScreenNo
            // 
            this.spnedt_ScreenNo.Location = new System.Drawing.Point(8, 32);
            this.spnedt_ScreenNo.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnedt_ScreenNo.Name = "spnedt_ScreenNo";
            this.spnedt_ScreenNo.Size = new System.Drawing.Size(82, 21);
            this.spnedt_ScreenNo.TabIndex = 1;
            this.spnedt_ScreenNo.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "屏号";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.trackBar1);
            this.groupBox6.Controls.Add(this.button8);
            this.groupBox6.Location = new System.Drawing.Point(7, 80);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(360, 112);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "调整显示屏亮度";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(14, 22);
            this.trackBar1.Maximum = 16;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(340, 45);
            this.trackBar1.TabIndex = 1;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBar1.Value = 16;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(234, 73);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(120, 23);
            this.button8.TabIndex = 0;
            this.button8.Text = "调整亮度";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button7);
            this.groupBox5.Controls.Add(this.button6);
            this.groupBox5.Location = new System.Drawing.Point(373, 10);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(360, 57);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "定时开关机";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(138, 21);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(120, 23);
            this.button7.TabIndex = 1;
            this.button7.Text = "取消定时开关机";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(7, 20);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(120, 23);
            this.button6.TabIndex = 0;
            this.button6.Text = "定时开关机";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Location = new System.Drawing.Point(7, 10);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(360, 56);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "强制开、关机";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(138, 20);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(120, 23);
            this.button5.TabIndex = 1;
            this.button5.Text = "强制关机";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(7, 20);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(120, 23);
            this.button4.TabIndex = 0;
            this.button4.Text = "强制开机";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(269, 3);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(119, 27);
            this.button16.TabIndex = 8;
            this.button16.Text = "删除系统当前节目";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // spnedt_curProgramOrd
            // 
            this.spnedt_curProgramOrd.Location = new System.Drawing.Point(183, 6);
            this.spnedt_curProgramOrd.Name = "spnedt_curProgramOrd";
            this.spnedt_curProgramOrd.Size = new System.Drawing.Size(75, 21);
            this.spnedt_curProgramOrd.TabIndex = 7;
            this.spnedt_curProgramOrd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.spnedt_curProgramOrd.ValueChanged += new System.EventHandler(this.numericUpDown4_ValueChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(100, 11);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 6;
            this.label12.Text = "当前节目序号";
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(12, 6);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 24);
            this.button15.TabIndex = 5;
            this.button15.Text = "添加节目";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(620, 218);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(106, 23);
            this.button14.TabIndex = 0;
            this.button14.Text = "停止更新节目";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(493, 218);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(121, 23);
            this.button13.TabIndex = 4;
            this.button13.Text = "开始更新节目";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(360, 218);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(127, 23);
            this.button12.TabIndex = 3;
            this.button12.Text = "发送显示屏节目信息";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(280, 218);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(74, 23);
            this.button11.TabIndex = 2;
            this.button11.Text = "保存到USB";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(12, 218);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(126, 23);
            this.button10.TabIndex = 1;
            this.button10.Text = "查询当前显示屏状态";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(557, 58);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(150, 23);
            this.button21.TabIndex = 8;
            this.button21.Text = "删除系统当前节目区域";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(12, 36);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(537, 176);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.Alignment);
            this.tabPage1.Controls.Add(this.label29);
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Controls.Add(this.spnedt_curFileOrd);
            this.tabPage1.Controls.Add(this.button20);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.button17);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(529, 150);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "图文类区域编辑";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // Alignment
            // 
            this.Alignment.FormattingEnabled = true;
            this.Alignment.Items.AddRange(new object[] {
            "居左",
            "居中",
            "居右"});
            this.Alignment.Location = new System.Drawing.Point(414, 14);
            this.Alignment.Name = "Alignment";
            this.Alignment.Size = new System.Drawing.Size(67, 20);
            this.Alignment.TabIndex = 10;
            this.Alignment.Text = "居中";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(359, 17);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(53, 12);
            this.label29.TabIndex = 9;
            this.label29.Text = "起始位置";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Location = new System.Drawing.Point(12, 37);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(345, 100);
            this.tabControl2.TabIndex = 8;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label13);
            this.tabPage6.Controls.Add(this.textBox2);
            this.tabPage6.Controls.Add(this.button18);
            this.tabPage6.Controls.Add(this.button19);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(337, 74);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "添加文件";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 2;
            this.label13.Text = "文件名称";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(58, 18);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(243, 21);
            this.textBox2.TabIndex = 1;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(307, 18);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(28, 23);
            this.button18.TabIndex = 3;
            this.button18.Text = "file";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(184, 45);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(151, 23);
            this.button19.TabIndex = 4;
            this.button19.Text = "添加文件到当前图文区域";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.button34);
            this.tabPage7.Controls.Add(this.richTextBox1);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(337, 74);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "添加文本";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(177, 48);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(157, 23);
            this.button34.TabIndex = 1;
            this.button34.Text = "添加文本到当前图文区域";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(3, 3);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(332, 42);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // spnedt_curFileOrd
            // 
            this.spnedt_curFileOrd.Location = new System.Drawing.Point(466, 42);
            this.spnedt_curFileOrd.Name = "spnedt_curFileOrd";
            this.spnedt_curFileOrd.Size = new System.Drawing.Size(60, 21);
            this.spnedt_curFileOrd.TabIndex = 6;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(368, 75);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(129, 23);
            this.button20.TabIndex = 7;
            this.button20.Text = "删除系统当前文件";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(359, 44);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(107, 12);
            this.label14.TabIndex = 5;
            this.label14.Text = "当前文件/文本序号";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(12, 6);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(92, 23);
            this.button17.TabIndex = 0;
            this.button17.Text = "添加图文区域";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.button29);
            this.tabPage2.Controls.Add(this.button28);
            this.tabPage2.Controls.Add(this.button27);
            this.tabPage2.Controls.Add(this.button26);
            this.tabPage2.Controls.Add(this.button25);
            this.tabPage2.Controls.Add(this.button24);
            this.tabPage2.Controls.Add(this.button23);
            this.tabPage2.Controls.Add(this.button22);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(529, 150);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "时间类区域编辑";
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(214, 102);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(142, 23);
            this.button29.TabIndex = 7;
            this.button29.Text = "添加/修改计时区域文件";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(117, 102);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(91, 23);
            this.button28.TabIndex = 6;
            this.button28.Text = "添加计时区域";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(214, 73);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(142, 23);
            this.button27.TabIndex = 5;
            this.button27.Text = "添加/修改表盘区域文件";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(117, 73);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(91, 23);
            this.button26.TabIndex = 4;
            this.button26.Text = "添加表盘区域";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(214, 44);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(142, 23);
            this.button25.TabIndex = 3;
            this.button25.Text = "添加/修改农历区域文件";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(117, 44);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(91, 23);
            this.button24.TabIndex = 2;
            this.button24.Text = "添加农历区域";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(214, 15);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(142, 23);
            this.button23.TabIndex = 1;
            this.button23.Text = "添加/修改时间区域文件";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(117, 15);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(91, 23);
            this.button22.TabIndex = 0;
            this.button22.Text = "添加时间区域";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.button30);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(529, 150);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "温度区域";
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(3, 6);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(95, 23);
            this.button30.TabIndex = 0;
            this.button30.Text = "添加温度区域";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage4.Controls.Add(this.button31);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(529, 150);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "湿度区域";
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(3, 6);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(90, 23);
            this.button31.TabIndex = 0;
            this.button31.Text = "添加湿度区域";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage5.Controls.Add(this.button32);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(529, 150);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "噪音区域";
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(3, 6);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(89, 23);
            this.button32.TabIndex = 0;
            this.button32.Text = "添加噪音区域";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // spnedt_curAreaOrd
            // 
            this.spnedt_curAreaOrd.Location = new System.Drawing.Point(626, 27);
            this.spnedt_curAreaOrd.Name = "spnedt_curAreaOrd";
            this.spnedt_curAreaOrd.Size = new System.Drawing.Size(81, 21);
            this.spnedt_curAreaOrd.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(555, 36);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 6;
            this.label15.Text = "当前区域号";
            // 
            // rchMessage
            // 
            this.rchMessage.Location = new System.Drawing.Point(12, 604);
            this.rchMessage.Multiline = true;
            this.rchMessage.Name = "rchMessage";
            this.rchMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.rchMessage.Size = new System.Drawing.Size(762, 87);
            this.rchMessage.TabIndex = 3;
            this.rchMessage.TextChanged += new System.EventHandler(this.rchMessage_TextChanged);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button35);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(764, 51);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "第一步-----初始化动态库";
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(12, 20);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(103, 23);
            this.button35.TabIndex = 0;
            this.button35.Text = "初始化动态库";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.comboBox1);
            this.groupBox10.Controls.Add(this.label30);
            this.groupBox10.Controls.Add(this.grp_Server);
            this.groupBox10.Controls.Add(this.label1);
            this.groupBox10.Controls.Add(this.grp_GPRS);
            this.groupBox10.Controls.Add(this.grp_Network);
            this.groupBox10.Controls.Add(this.comboBox5);
            this.groupBox10.Controls.Add(this.button3);
            this.groupBox10.Controls.Add(label11);
            this.groupBox10.Controls.Add(this.grp_SerialPort);
            this.groupBox10.Controls.Add(this.button2);
            this.groupBox10.Controls.Add(this.spnedt_ScreenNo);
            this.groupBox10.Controls.Add(this.button1);
            this.groupBox10.Controls.Add(this.label3);
            this.groupBox10.Controls.Add(this.comboBox2);
            this.groupBox10.Controls.Add(this.label4);
            this.groupBox10.Controls.Add(this.nSendMode);
            this.groupBox10.Controls.Add(this.label8);
            this.groupBox10.Controls.Add(this.spnedt_Width);
            this.groupBox10.Controls.Add(this.label9);
            this.groupBox10.Controls.Add(this.label10);
            this.groupBox10.Controls.Add(this.spnedt_Height);
            this.groupBox10.Location = new System.Drawing.Point(13, 70);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(763, 162);
            this.groupBox10.TabIndex = 5;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "第二步-----初始化显示屏参数";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.tabControl3);
            this.groupBox11.Location = new System.Drawing.Point(13, 240);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(763, 300);
            this.groupBox11.TabIndex = 7;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "第三步-----节目/命令信息";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage8);
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Location = new System.Drawing.Point(11, 21);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(740, 273);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.btnQueryScreenParameter);
            this.tabPage8.Controls.Add(this.button14);
            this.tabPage8.Controls.Add(this.button21);
            this.tabPage8.Controls.Add(this.button13);
            this.tabPage8.Controls.Add(this.button16);
            this.tabPage8.Controls.Add(this.button12);
            this.tabPage8.Controls.Add(this.tabControl1);
            this.tabPage8.Controls.Add(this.button11);
            this.tabPage8.Controls.Add(this.spnedt_curAreaOrd);
            this.tabPage8.Controls.Add(this.button10);
            this.tabPage8.Controls.Add(this.spnedt_curProgramOrd);
            this.tabPage8.Controls.Add(this.button15);
            this.tabPage8.Controls.Add(this.label15);
            this.tabPage8.Controls.Add(this.label12);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(732, 247);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "节目信息";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // btnQueryScreenParameter
            // 
            this.btnQueryScreenParameter.Location = new System.Drawing.Point(141, 218);
            this.btnQueryScreenParameter.Name = "btnQueryScreenParameter";
            this.btnQueryScreenParameter.Size = new System.Drawing.Size(139, 23);
            this.btnQueryScreenParameter.TabIndex = 9;
            this.btnQueryScreenParameter.Text = "查询显示屏参数";
            this.btnQueryScreenParameter.UseVisualStyleBackColor = true;
            this.btnQueryScreenParameter.Click += new System.EventHandler(this.btnQueryScreenParameter_Click);
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.groupBox7);
            this.tabPage9.Controls.Add(this.groupBox4);
            this.tabPage9.Controls.Add(this.groupBox6);
            this.tabPage9.Controls.Add(this.groupBox5);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(732, 247);
            this.tabPage9.TabIndex = 1;
            this.tabPage9.Text = "命令信息";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button9);
            this.groupBox7.Location = new System.Drawing.Point(373, 91);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(360, 56);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "其他命令";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(7, 21);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(120, 23);
            this.button9.TabIndex = 0;
            this.button9.Text = "校正时间";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(19, 20);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(110, 23);
            this.button36.TabIndex = 0;
            this.button36.Text = "释放动态库";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button39);
            this.groupBox1.Controls.Add(this.button36);
            this.groupBox1.Location = new System.Drawing.Point(13, 546);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(763, 52);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "第四步-----释放动态库";
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(145, 20);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(113, 23);
            this.button39.TabIndex = 1;
            this.button39.Text = "退出程序";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // grp_wifi
            // 
            this.grp_wifi.Controls.Add(this.btnWiFiStopServer);
            this.grp_wifi.Controls.Add(this.btnWiFiStartServer);
            this.grp_wifi.Controls.Add(this.tbWiFiNetID);
            this.grp_wifi.Controls.Add(this.lbWiFiNetID);
            this.grp_wifi.Controls.Add(this.numWiFiPort);
            this.grp_wifi.Controls.Add(this.label24);
            this.grp_wifi.Controls.Add(this.tbWiFiIp);
            this.grp_wifi.Controls.Add(this.label23);
            this.grp_wifi.Controls.Add(this.rdbWiFiServerMode);
            this.grp_wifi.Controls.Add(this.rdbWiFiFixMode);
            this.grp_wifi.Location = new System.Drawing.Point(12, 129);
            this.grp_wifi.Name = "grp_wifi";
            this.grp_wifi.Size = new System.Drawing.Size(757, 64);
            this.grp_wifi.TabIndex = 1;
            this.grp_wifi.TabStop = false;
            this.grp_wifi.Text = "WIFI设置";
            // 
            // btnWiFiStopServer
            // 
            this.btnWiFiStopServer.Location = new System.Drawing.Point(467, 36);
            this.btnWiFiStopServer.Name = "btnWiFiStopServer";
            this.btnWiFiStopServer.Size = new System.Drawing.Size(98, 23);
            this.btnWiFiStopServer.TabIndex = 9;
            this.btnWiFiStopServer.Text = "关闭服务器";
            this.btnWiFiStopServer.UseVisualStyleBackColor = true;
            this.btnWiFiStopServer.Visible = false;
            this.btnWiFiStopServer.Click += new System.EventHandler(this.btnWiFiStopServer_Click);
            // 
            // btnWiFiStartServer
            // 
            this.btnWiFiStartServer.Location = new System.Drawing.Point(346, 36);
            this.btnWiFiStartServer.Name = "btnWiFiStartServer";
            this.btnWiFiStartServer.Size = new System.Drawing.Size(99, 23);
            this.btnWiFiStartServer.TabIndex = 8;
            this.btnWiFiStartServer.Text = "启动服务器";
            this.btnWiFiStartServer.UseVisualStyleBackColor = true;
            this.btnWiFiStartServer.Visible = false;
            this.btnWiFiStartServer.Click += new System.EventHandler(this.btnWiFiStartServer_Click);
            // 
            // tbWiFiNetID
            // 
            this.tbWiFiNetID.Location = new System.Drawing.Point(232, 38);
            this.tbWiFiNetID.Name = "tbWiFiNetID";
            this.tbWiFiNetID.Size = new System.Drawing.Size(100, 21);
            this.tbWiFiNetID.TabIndex = 7;
            this.tbWiFiNetID.Text = "BX-NET000001";
            this.tbWiFiNetID.Visible = false;
            // 
            // lbWiFiNetID
            // 
            this.lbWiFiNetID.AutoSize = true;
            this.lbWiFiNetID.Location = new System.Drawing.Point(255, 22);
            this.lbWiFiNetID.Name = "lbWiFiNetID";
            this.lbWiFiNetID.Size = new System.Drawing.Size(41, 12);
            this.lbWiFiNetID.TabIndex = 6;
            this.lbWiFiNetID.Text = "网络ID";
            this.lbWiFiNetID.Visible = false;
            // 
            // numWiFiPort
            // 
            this.numWiFiPort.Location = new System.Drawing.Point(121, 38);
            this.numWiFiPort.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numWiFiPort.Name = "numWiFiPort";
            this.numWiFiPort.Size = new System.Drawing.Size(98, 21);
            this.numWiFiPort.TabIndex = 5;
            this.numWiFiPort.Value = new decimal(new int[] {
            5005,
            0,
            0,
            0});
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(151, 22);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 12);
            this.label24.TabIndex = 4;
            this.label24.Text = "端口";
            // 
            // tbWiFiIp
            // 
            this.tbWiFiIp.Location = new System.Drawing.Point(7, 37);
            this.tbWiFiIp.Name = "tbWiFiIp";
            this.tbWiFiIp.Size = new System.Drawing.Size(100, 21);
            this.tbWiFiIp.TabIndex = 3;
            this.tbWiFiIp.Text = "192.168.100.1";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(30, 22);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 12);
            this.label23.TabIndex = 2;
            this.label23.Text = "IP地址";
            // 
            // rdbWiFiServerMode
            // 
            this.rdbWiFiServerMode.AutoSize = true;
            this.rdbWiFiServerMode.Location = new System.Drawing.Point(159, 0);
            this.rdbWiFiServerMode.Name = "rdbWiFiServerMode";
            this.rdbWiFiServerMode.Size = new System.Drawing.Size(83, 16);
            this.rdbWiFiServerMode.TabIndex = 1;
            this.rdbWiFiServerMode.TabStop = true;
            this.rdbWiFiServerMode.Text = "服务器模式";
            this.rdbWiFiServerMode.UseVisualStyleBackColor = true;
            this.rdbWiFiServerMode.CheckedChanged += new System.EventHandler(this.rdbWiFiServerMode_CheckedChanged);
            // 
            // rdbWiFiFixMode
            // 
            this.rdbWiFiFixMode.AutoSize = true;
            this.rdbWiFiFixMode.Location = new System.Drawing.Point(66, 0);
            this.rdbWiFiFixMode.Name = "rdbWiFiFixMode";
            this.rdbWiFiFixMode.Size = new System.Drawing.Size(83, 16);
            this.rdbWiFiFixMode.TabIndex = 0;
            this.rdbWiFiFixMode.TabStop = true;
            this.rdbWiFiFixMode.Text = "固定IP模式";
            this.rdbWiFiFixMode.UseVisualStyleBackColor = true;
            this.rdbWiFiFixMode.CheckedChanged += new System.EventHandler(this.rdbWiFiFixMode_CheckedChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(592, 17);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(89, 12);
            this.label30.TabIndex = 24;
            this.label30.Text = "固定IP通讯模式";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "TCP模式",
            "UDP模式"});
            this.comboBox1.Location = new System.Drawing.Point(594, 33);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(87, 20);
            this.comboBox1.TabIndex = 25;
            this.comboBox1.Text = "TCP模式";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(787, 703);
            this.Controls.Add(this.grp_wifi);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.rchMessage);
            this.Name = "Form1";
            this.Text = "C#_Demo";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.grp_GPRS.ResumeLayout(false);
            this.grp_GPRS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.edt_GprsPort)).EndInit();
            this.grp_Server.ResumeLayout(false);
            this.grp_Server.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            this.grp_Network.ResumeLayout(false);
            this.grp_Network.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            this.grp_SerialPort.ResumeLayout(false);
            this.grp_SerialPort.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_Height)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_Width)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_ScreenNo)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_curProgramOrd)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_curFileOrd)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spnedt_curAreaOrd)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.grp_wifi.ResumeLayout(false);
            this.grp_wifi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numWiFiPort)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown spnedt_ScreenNo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox nSendMode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.GroupBox grp_SerialPort;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown spnedt_Height;
        private System.Windows.Forms.NumericUpDown spnedt_Width;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox rchMessage;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.NumericUpDown spnedt_curProgramOrd;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.NumericUpDown spnedt_curAreaOrd;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox grp_Network;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton radbtn_ServerMode;
        private System.Windows.Forms.RadioButton radbtn_FixIPMode;
        private System.Windows.Forms.GroupBox grp_Server;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox grp_GPRS;
        private System.Windows.Forms.TextBox edt_GprsIP;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown edt_GprsPort;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox comb_GprsStyle;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox edt_GprsID;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown spnedt_curFileOrd;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox edtTransitNetworkID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox edtTransitBarcode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.GroupBox grp_wifi;
        private System.Windows.Forms.RadioButton rdbWiFiServerMode;
        private System.Windows.Forms.RadioButton rdbWiFiFixMode;
        private System.Windows.Forms.NumericUpDown numWiFiPort;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tbWiFiIp;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox tbWiFiNetID;
        private System.Windows.Forms.Label lbWiFiNetID;
        private System.Windows.Forms.Button btnWiFiStopServer;
        private System.Windows.Forms.Button btnWiFiStartServer;
        private System.Windows.Forms.Button btnQueryScreenParameter;
        private System.Windows.Forms.ComboBox Alignment;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label30;
    }
}